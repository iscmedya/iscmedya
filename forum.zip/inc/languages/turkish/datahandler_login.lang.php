<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['logindata_invalidpwordusername'] = "Geçersiz üye adı / şifre kombinasyonu girdiniz.<br /><br />Eğer şifrenizi unuttu iseniz lütfen<a href=\"member.php?action=lostpw\"> buraya tıklayınız.</a>";
$l['logindata_invalidpwordusernameemail'] = "Geçersiz e-posta / şifre kombinasyonu girdiniz.<br /><br />Eğer şifrenizi unuttu iseniz lütfen<a href=\"member.php?action=lostpw\"> buraya tıklayınız.</a>";
$l['logindata_invalidpwordusernamecombo'] = "Geçersiz üye adı şifre / e-posta şifre kombinasyonu girdiniz.<br /><br />Eğer şifrenizi unuttu iseniz lütfen<a href=\"member.php?action=lostpw\"> buraya tıklayınız.</a>";

$l['logindata_regimageinvalid'] = "Girdiğiniz resim doğrulama kodu yanlış. Görüntüdeki kodları tam olarak giriniz.";
$l['logindata_regimagerequired'] = "Lütfen devam etmek için görüntü doğrulama kodunu giriniz.. Lütfen görüntüdeki kodları tam olarak giriniz.";
