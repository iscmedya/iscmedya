<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['nav_showteam'] = 'Forum Takımı';
$l['forum_team'] = 'Forum Takımı';
$l['moderators'] = 'Moderatörler';
$l['username'] = 'Kullanıcı Adı';
$l['lastvisit'] = 'Son Ziyaret';
$l['email'] = 'Email';
$l['pm'] = 'ÖM';
$l['mod_forums'] = 'Forumlar';
$l['mod_groups'] = 'Gruplar';
$l['online'] = 'Çevrimiçi';
$l['offline'] = 'Çevrimdışı';
$l['away'] = 'Uzakta';

$l['group_leaders'] = 'Lider(ler)';
$l['group_members'] = 'Üye(ler)';

$l['no_members'] = 'Bu grupta üye bulunmamaktadır';
$l['error_noteamstoshow'] = 'Gösterilebilecek forum yetkilisi bulunmamaktadır.';
$l['showteam_disabled'] = 'Forum Takımı Listesi Yönetici tarafından devre dışı bırakıldı.';
