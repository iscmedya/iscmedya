<?php
###################################
# Plugin AutoMedia for MyBB*#
# (c) 2009-2018 by doylecc    #
# Website: http://mybbplugins.tk #
###################################

$l['av_sigreplace'] = "Video/Audio embedding in signatures is disabled. To enter the URL as link, please use the \"amoff\" MyCode. [amoff]URL[/amoff]";
$l['av_editsig'] = "Video/Audio embedding in signatures is disabled. Embedded files won't be shown in threads. To enter the URL as link, please use the \"amoff\" MyCode. [amoff]URL[/amoff]";
$l['av_threadpreview'] = "EMBEDDED MEDIA";
$l['av_ampl'] = "MP3 Playlist";
$l['av_amoff'] = "Disable AutoMedia embedding for this link.";
$l['av_vidcount'] = "Your post contains too many videos. Max. videos allowed:";
$l['av_click'] = "Embed";
$l['av_ucp_menu'] = "AutoMedia";
$l['av_ucp_title'] = "AutoMedia in Posts";
$l['av_ucp_status'] = "Status:";
$l['av_ucp_label'] = "Activate automatic link embedding: ";
$l['av_ucp_yes'] = "Yes";
$l['av_ucp_no'] = "No";
$l['av_ucp_submit'] = "Submit";
$l['av_ucp_submit_success'] = "AutoMedia setting updated successfully!";
$l['av_image_na'] = "No preview image available!";
$l['av_preview_na'] = "Preview not available!";
