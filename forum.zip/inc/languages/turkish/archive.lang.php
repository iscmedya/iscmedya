<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['archive_fullversion'] = "Tam Versiyon:";
$l['archive_replies'] = "Cevap";
$l['archive_reply'] = "Cevap";
$l['archive_pages'] = "Sayfa:";
$l['archive_note'] = "Şu anda tam olmayan bir versiyonun içeriğine bakıyorsunuz. <a href=\"{1}\">Tam versiyon</a>'a bakınız.";
$l['archive_nopermission'] = "Üzgünüz, bu kaynağa erişim izininiz yok.";
$l['error_nothreads'] = "Şu anda bu forumda konu yok.";
$l['error_nopermission'] = "Bu forumda konuları görüntülemek için izniniz yok.";
$l['error_unapproved_thread'] = "Bu konu onaylanmamış. Bu konunun içeriğini görüntülemek için, Lütfen<a href=\"{1}\">Tam versiyon</a>'a bakınız.";
$l['archive_not_found'] = "Belirtilen döküman bu sunucuda bulunamadı.";
$l['error_mustlogin'] = "Bu modu görüntülemek için tüm kullanıcıların foruma giriş yapmış olması gerekir.";