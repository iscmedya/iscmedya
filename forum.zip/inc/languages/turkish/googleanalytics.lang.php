<?php
// Language file (english) for MyBB Plugin Google Analytics
// © 2014 - 2015 juventiner
// ---------------------------------------------------
// Last Update: 22.09.2015

$l['googleanalytics_disable_usercp'] = 'Please don\'t track me via <a href="https://en.wikipedia.org/wiki/Google_Analytics" target="_blank">Google Analytics</a>.';

?>