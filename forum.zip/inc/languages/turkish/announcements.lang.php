<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['nav_announcements'] = "Forum Duyurusu";
$l['announcements'] = "Duyuru";
$l['forum_announcement'] = "Forum Duyurusu: {1}";
$l['error_invalidannouncement'] = "Belirtilen duyuru geçersizdir.";

$l['announcement_edit'] = "Duyuruyu düzenle";
$l['announcement_qdelete'] = "Duyuruyu sil";
$l['announcement_quickdelete_confirm'] = "Bu duyuruyu silmek istediğinizden emin misiniz?";
