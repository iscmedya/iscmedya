<?php 
/**
 * Thanks Plugin - english
 */

$l['thx_main'] = "Thanks";
$l['thx_givenby'] = "Thanks given by:";
$l['thx_thanked_count'] = "Given {1} thank(s) in {2} post(s)";
$l['thx_thank'] = "Thanks:";
$l['thx_remove'] = "Remove thank";
$l['thx_comma'] = " , ";
$l['thx_dir'] = "ltr";
?>