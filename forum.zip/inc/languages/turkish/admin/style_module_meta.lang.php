<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['templates_and_style'] = "Şablon &amp; Stil";

$l['themes'] = "Temalar";
$l['templates'] = "Şablonlar";

$l['can_manage_themes'] = "Temaları Yönetebilir mi?";
$l['can_manage_templates'] = "Şablonları Yönetebilir mi?";

