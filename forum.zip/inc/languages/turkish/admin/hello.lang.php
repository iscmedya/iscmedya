<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['hello_desc'] = 'Ana sayfada mesaj oluşturmanıza olanak sağlayan ve bunları her gönderiye ekleyen örnek bir eklenti.';

$l['setting_group_hello'] = 'Merhaba Dünya!';
$l['setting_group_hello_desc'] = 'Merhaba Dünya Eklenti Ayarları';

$l['setting_hello_display1'] = 'Mesajları Ana Sayfada Göster';
$l['setting_hello_display1_desc'] = 'Mesajları ana sayfada görüntülemek istemiyorsanız hayır olarak ayarlayın.';

$l['setting_hello_display2'] = 'Mesajları Postbitte Göster';
$l['setting_hello_display2_desc'] = 'Her yazının altındaki mesajları görüntülemek istemiyorsanız hayır olarak ayarlayın.';

$l['hello_uninstall'] = 'Merhaba Dünya! kaldırma';
$l['hello_uninstall_message'] = 'Tüm mesajları veritabanından kaldırmak istiyor musunuz?';