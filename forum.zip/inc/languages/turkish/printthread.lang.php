<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['forum'] = "Forum:";
$l['printable_version'] = "Yazdırılabilir Sürüm";
$l['pages'] = "Sayfalar:";
$l['thread'] = "Konu:";
