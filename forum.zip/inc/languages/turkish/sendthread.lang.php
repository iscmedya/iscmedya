<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['nav_sendthread'] = "Konuyu Arkadaşıma Gönder";

$l['send_thread'] = "Arkadaşıma Gönder";
$l['recipient'] = "Alıcı:";
$l['recipient_note'] = "Buraya arkadaşınızın email adresini girin.";
$l['subject'] = "Konu:";
$l['message'] = "Mesaj:";
$l['error_nosubject'] = "Konunuzu göndermek için mesaja bir başlık girmeniz gerekmektedir.";
$l['error_nomessage'] = "Bu konuyu bir arkadaşınıza göndermeden önce bir mesaj girmeniz gerekmektedir.";
