<?php

$l['googleseo_404_notfound'] = "404 Sayfa Bulunamadı";
$l['googleseo_404_widget'] = "<script type=\"text/javascript\">\nvar GOOG_FIXURL_LANG = 'tr';\nvar GOOG_FIXURL_SITE = '{1}';\n</script>\n<script type=\"text/javascript\" src=\"http://linkhelp.clients.google.com/tbproxy/lh/wm/fixurl.js\"></script>";
$l['googleseo_404_wol'] = "<a href=\"{1}\">Hata Sayfası</a> olarak görüntüleniyor.";
$l['googleseo_meta_page'] = "Sayfa";
$l['googleseo_sitemap_disabledorinvalid'] = "Site haritası/Sitemap devre dışı veya geçersiz.";
$l['googleseo_sitemap_emptyorinvalid'] = "Site haritası ya boş yada geçersiz sayfa.";
$l['googleseo_sitemap_pageinvalid'] = "Geçersiz sitemap sayfası!";
$l['googleseo_sitemap_wol'] = "<a href=\"{1}\">XML Sitemap</a>ı İnceliyor";

?>