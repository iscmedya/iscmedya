<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['all_forums'] = "Tüm Forumlar";
$l['forum'] = "Forum:";
$l['posted_by'] = "Gönderen:";
$l['on'] = "Açık";
$l['portal'] = "Portal";
