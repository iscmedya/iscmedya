<?php
/**
 * MyBB 1.8 Türkçe Dil Paketi
 * Telif Hakkı 2019 MyBBKursu.Com (**SaBRoZa**), Her Hakkı Saklıdır
 *
 */

$l['hello'] = 'Merhaba Dünya!';
$l['hello_add'] = 'Ekle';
$l['hello_add_message'] = 'Mesaj Ekle';
$l['hello_empty'] = 'Hiçbir mesajlar bulunamadı.';
$l['hello_message_empty'] = 'Mesaj boş olamaz.';
$l['hello_done'] = 'Başarıyla yeni bir mesaj ekledi.';